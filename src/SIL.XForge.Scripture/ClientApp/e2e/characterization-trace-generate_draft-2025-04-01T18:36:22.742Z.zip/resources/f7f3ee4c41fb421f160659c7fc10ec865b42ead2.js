a["{\"msg\":\"removed\",\"collection\":\"kadira_settings\",\"id\":\"gfBWL6zRgG63zWXfi\"}"]
